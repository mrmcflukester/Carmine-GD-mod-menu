#pragma once

#include <Geode/Geode.hpp>
#include <array>
#include <functional>
#include <string>
#include <vector>

namespace modmenu {

// The 5 categories, in tab order.
inline constexpr std::array<const char*, 5> CATEGORIES = {
    "Cosmetics", "Optimizations", "Macros", "Shitposts", "Cheat Safety"
};

struct ModEntry {
    std::string id;           // used as the saved-setting key
    std::string name;
    std::string description;
    std::function<void(bool)> onToggle; // called with the new state
};

// One list of mods per category (same index as CATEGORIES).
inline std::array<std::vector<ModEntry>, 5>& registry() {
    static std::array<std::vector<ModEntry>, 5> reg;
    return reg;
}

// Call this from anywhere (e.g. $on_mod(Loaded) or a static initializer) to add a mod:
//   modmenu::addMod(0, {"fancy-icon", "Fancy Icon", "Does a thing", [](bool on){ ... }});
inline void addMod(size_t category, ModEntry entry) {
    registry().at(category).push_back(std::move(entry));
}

} // namespace modmenu
