#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include "Registry.hpp"

using namespace geode::prelude;

// ---------------------------------------------------------------------------
// The menu popup: 5 tab buttons on top, content area below.
// ---------------------------------------------------------------------------
class ModMenuPopup : public geode::Popup<> {
protected:
    size_t m_current = 0;
    std::vector<CCMenuItemSpriteExtra*> m_tabButtons;
    CCNode* m_content = nullptr;

    bool setup() override {
        this->setTitle("Mod Menu");

        auto size = m_mainLayer->getContentSize();

        // --- tab row ---
        auto tabMenu = CCMenu::create();
        tabMenu->setPosition({size.width / 2, size.height - 48.f});
        tabMenu->setContentSize({size.width - 20.f, 30.f});
        tabMenu->setLayout(
            RowLayout::create()->setGap(4.f)->setAutoScale(true)
        );
        m_mainLayer->addChild(tabMenu);

        for (size_t i = 0; i < modmenu::CATEGORIES.size(); i++) {
            auto spr = ButtonSprite::create(
                modmenu::CATEGORIES[i], 80, true, "bigFont.fnt", "GJ_button_04.png", 30.f, 0.5f
            );
            auto btn = CCMenuItemSpriteExtra::create(
                spr, this, menu_selector(ModMenuPopup::onTab)
            );
            btn->setTag(static_cast<int>(i));
            tabMenu->addChild(btn);
            m_tabButtons.push_back(btn);
        }
        tabMenu->updateLayout();

        // --- content area ---
        m_content = CCNode::create();
        m_content->setContentSize({size.width - 30.f, size.height - 90.f});
        m_content->setAnchorPoint({0.5f, 0.5f});
        m_content->setPosition({size.width / 2, (size.height - 60.f) / 2});
        m_mainLayer->addChild(m_content);

        this->showCategory(0);
        return true;
    }

    void onTab(CCObject* sender) {
        this->showCategory(static_cast<size_t>(sender->getTag()));
    }

    void showCategory(size_t index) {
        m_current = index;
        m_content->removeAllChildren();

        // highlight the selected tab
        for (size_t i = 0; i < m_tabButtons.size(); i++) {
            auto spr = static_cast<ButtonSprite*>(m_tabButtons[i]->getNormalImage());
            spr->setColor(i == index ? ccColor3B{255, 255, 255} : ccColor3B{150, 150, 150});
        }

        auto csize = m_content->getContentSize();
        auto& mods = modmenu::registry()[index];

        if (mods.empty()) {
            auto label = CCLabelBMFont::create(
                fmt::format("No {} mods yet.", modmenu::CATEGORIES[index]).c_str(),
                "bigFont.fnt"
            );
            label->setScale(0.5f);
            label->setOpacity(150);
            label->setPosition(csize / 2);
            m_content->addChild(label);
            return;
        }

        // one toggler row per mod
        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        menu->setContentSize(csize);
        m_content->addChild(menu);

        float y = csize.height - 20.f;
        for (auto& mod : mods) {
            auto toggler = CCMenuItemToggler::createWithStandardSprites(
                this, menu_selector(ModMenuPopup::onToggle), 0.6f
            );
            toggler->setUserObject(CCString::create(mod.id));
            toggler->toggle(Mod::get()->getSavedValue<bool>(mod.id, false));
            toggler->setPosition({25.f, y});
            menu->addChild(toggler);

            auto label = CCLabelBMFont::create(mod.name.c_str(), "bigFont.fnt");
            label->setScale(0.5f);
            label->setAnchorPoint({0.f, 0.5f});
            label->setPosition({50.f, y});
            m_content->addChild(label);

            y -= 30.f;
        }
    }

    void onToggle(CCObject* sender) {
        auto toggler = static_cast<CCMenuItemToggler*>(sender);
        auto id = static_cast<CCString*>(toggler->getUserObject())->getCString();
        // callback fires before the visual state flips, so invert
        bool enabled = !toggler->isToggled();
        Mod::get()->setSavedValue<bool>(id, enabled);

        for (auto& mod : modmenu::registry()[m_current]) {
            if (mod.id == id && mod.onToggle) mod.onToggle(enabled);
        }
    }

public:
    static ModMenuPopup* create() {
        auto ret = new ModMenuPopup();
        if (ret->initAnchored(440.f, 280.f)) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
};

// ---------------------------------------------------------------------------
// Button on the main menu to open it.
// ---------------------------------------------------------------------------
class $modify(ModMenuMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;

        auto spr = CircleButtonSprite::createWithSprite(
            "GJ_optionsBtn_001.png", 0.8f, CircleBaseColor::Green, CircleBaseSize::Medium
        );
        auto btn = CCMenuItemSpriteExtra::create(
            spr, this, menu_selector(ModMenuMenuLayer::onOpenModMenu)
        );
        btn->setID("mod-menu-button"_spr);

        if (auto menu = this->getChildByID("bottom-menu")) {
            menu->addChild(btn);
            menu->updateLayout();
        }
        return true;
    }

    void onOpenModMenu(CCObject*) {
        ModMenuPopup::create()->show();
    }
};
